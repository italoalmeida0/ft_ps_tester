from ft_ps_tester.cli import main

if __name__ == "__main__":
    main()
